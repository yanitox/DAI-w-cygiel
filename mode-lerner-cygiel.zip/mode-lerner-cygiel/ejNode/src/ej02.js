import {PI, sumar, restar, multiplicar, dividir} from './modules/matematica.js';
let result, num1=10, num2=20;
console.clear();
console.log(`La constante PI vale '${PI}'`); // Uso la constante PI importada.

result = sumar(num1, num2);
console.log(`sumar(${num1}, + ${num2}) = ${result}`);

result = restar(num1, num2);
console.log(`restar(${num1}, - ${num2}) = ${result}`);

result = multiplicar(num1, num2);
console.log(`multiplicar(${num1}, * ${num2}) = ${result}`);

result = dividir(num1, num2); // Uso la función sumar importada.
console.log(`dividir(${num1}, : ${num2}) = ${result}`);