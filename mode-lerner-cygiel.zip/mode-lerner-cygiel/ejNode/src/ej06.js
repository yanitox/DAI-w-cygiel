let elURL = null;
let miObjeto = null;
elURL = 'http://www.ort.edu.ar:8080/alumnos/index.htm?curso=2022&mes=mayo';
miObjeto = parsearUrl (elURL);
console.log(miObjeto);

function parsearUrl(laURL) {
    let params = {};

    try {
        let urlObjeto = new URL(laURL);
        params.host = urlObjeto.origin;
        params.ruta = urlObjeto.pathname;
        params.parametros = Object.fromEntries(urlObjeto.searchParams.entries());
    } catch (error) {
        console.error('Error al parsear la URL:', error);
        // Si ocurre una excepción, establecer todas las propiedades en null
        params.host = null;
        params.ruta = null;
        params.parametros = {};
    }

    return params;
}