import { getCurrency } from 'currency-map-country';

let monedaDelPais, codigoPais;
codigoPais = 'AR';
monedaDelPais = obtenerCountry(codigoPais);
console.log(`La moneda del país ${codigoPais} es: ${monedaDelPais}`);
codigoPais = 'UsA';
monedaDelPais = obtenerCountry(codigoPais);
console.log(`La moneda del país ${codigoPais} es: ${monedaDelPais}`);

function obtenerCountry(codigo){
    let moneda;
    moneda=obtenerCountry(codigo); 
    return moneda;
}

