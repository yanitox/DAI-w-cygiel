/* Módulo OMDBWrapper*/
process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = 0;    
import axios from "axios";
const APIKEY = "c246fa75"; // Poné tu APIKEY, esta no funciona.
const OMDBSearchByPage = async (searchText, page = 1) => {
    let returnObject = {
        respuesta : false,
        cantidadresult : 0,
        datos : {}
    };

    const requestString = `https://www.omdbapi.com/?apikey=${APIKEY}&s=${searchText}&page=${page}`;
    const apiResponse = await axios.get(requestString);
    returnObject.datos = apiResponse.data.Search;  
    returnObject.respuesta=apiResponse.data.Response;
    returnObject.cantidadresult = apiResponse.data.resultResults;
    return returnObject;
};

const OMDBSearchComplete = async (searchText, page=1) => {
let returnObject = {
respuesta : false,
cantidadresult : 0,
datos : {}
};
const requestString = `https://www.omdbapi.com/?apikey=${APIKEY}&s=${searchText}&page=${page}`;
    const apiResponse = await axios.get(requestString);
    returnObject.datos = apiResponse.data.Search;
    returnObject.respuesta=apiResponse.data.Response;  
    returnObject.cantidadresult = apiResponse.data.resultResults;
    return returnObject;
};
const OMDBGetByImdbID = async (imdbID, page=1) => {
let returnObject = {
respuesta : false,
cantidadresult : 0,
datos : {}
};
const requestString = `https://www.omdbapi.com/?apikey=${APIKEY}&s=${imdbID}&page=${page}`;
    const apiResponse = await axios.get(requestString);
    returnObject.datos = apiResponse.data.Search;
    returnObject.respuesta=apiResponse.data.Response;  
    returnObject.cantidadresult = apiResponse.data.resultResults;
    return returnObject;
    };
// Exporto todo lo que yo quiero exponer del módulo:
export {OMDBSearchByPage, OMDBSearchComplete, OMDBGetByImdbID};